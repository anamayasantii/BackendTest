<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Input Rating</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <div class="container mt-5">
        <h1 class="text-center mb-4">Input Rating</h1>

        <!-- Form untuk input rating -->
        <form method="GET" action="<?php echo e(route('ratings.create')); ?>" class="mb-4">
            <!-- Dropdown Penulis -->
            <div class="mb-3">
                <label for="author_id" class="form-label">Pilih Penulis</label>
                <select name="author_id" id="author_id" class="form-select" onchange="this.form.submit()" required>
                    <option value="" disabled <?php echo e(!$selectedAuthor ? 'selected' : ''); ?>>Pilih penulis...</option>
                    <?php $__currentLoopData = $authors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $author): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($author->id); ?>" <?php echo e($selectedAuthor == $author->id ? 'selected' : ''); ?>>
                            <?php echo e($author->name); ?>

                        </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
        </form>

        <?php if($selectedAuthor): ?>
        <form method="POST" action="<?php echo e(route('ratings.store')); ?>">
            <?php echo csrf_field(); ?>

            <!-- Dropdown Buku -->
            <div class="mb-3">
                <label for="book_id" class="form-label">Pilih Buku</label>
                <select name="book_id" id="book_id" class="form-select" required>
                    <option value="" selected disabled>Pilih buku...</option>
                    <?php $__currentLoopData = $books; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $book): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($book->id); ?>"><?php echo e($book->title); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>

            <!-- Dropdown Rating -->
            <div class="mb-3">
                <label for="rating" class="form-label">Rating</label>
                <select name="rating" id="rating" class="form-select" required>
                    <option value="" selected disabled>Pilih rating...</option>
                    <?php for($i = 1; $i <= 10; $i++): ?>
                        <option value="<?php echo e($i); ?>"><?php echo e($i); ?></option>
                    <?php endfor; ?>
                </select>
            </div>

            <!-- Tombol Submit -->
            <div class="text-center">
                <button type="submit" class="btn btn-primary">Submit Rating</button>
                <a href="<?php echo e(route('books.index')); ?>" class="btn btn-secondary">Kembali</a>
            </div>
        </form>
        <?php endif; ?>
    </div>
</body>
</html>
<?php /**PATH C:\laragon\www\book-laravel\resources\views/books/rating.blade.php ENDPATH**/ ?>