<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Daftar Buku</title>
    <!-- Link Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <div class="container mt-5">
        <h1 class="text-center mb-4">Daftar Buku</h1>

        <!-- Filter dan Pencarian -->
        <form method="GET" action="<?php echo e(route('books.index')); ?>" class="mb-4">
            <div class="row">
                <div class="col-md-6">
                    <input type="text" name="search" placeholder="Cari buku atau penulis" class="form-control" value="<?php echo e(request('search')); ?>">
                </div>
                <div class="col-md-2">
                    <select name="per_page" class="form-select">
                        <option value="10" <?php echo e(request('per_page') == '10' ? 'selected' : ''); ?>>10</option>
                        <option value="20" <?php echo e(request('per_page') == '20' ? 'selected' : ''); ?>>20</option>
                        <option value="50" <?php echo e(request('per_page') == '50' ? 'selected' : ''); ?>>50</option>
                        <option value="100" <?php echo e(request('per_page') == '100' ? 'selected' : ''); ?>>100</option>
                    </select>
                </div>
                <div class="col-md-3">
                    <button type="submit" class="btn btn-primary">Cari</button>
                    <a href="/popular-authors" class="btn btn-success">Popular Authors</a>
                    <a href="/ratings/create" class="btn btn-success">Rate</a>
                </div>
            </div>
        </form>

        <!-- Daftar Buku -->
        <table class="table table-striped table-bordered">
            <thead>
                <tr>
                    <th>No</th>
                    <th>Judul Buku</th>
                    <th>Penulis</th>
                    <th>Rating Rata-rata</th>
                    <th>Jumlah Voter</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $books; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $book): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($loop->iteration + $books->firstItem() - 1); ?></td>
                        <td><?php echo e($book->title); ?></td>
                        <td><?php echo e($book->author ? $book->author->name : 'Penulis tidak ditemukan'); ?></td>
                        <td><?php echo e(number_format($book->average_rating, 1)); ?></td>
                        <td><?php echo e($book->total_voters); ?></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>

        <!-- Pagination -->
        <div class="d-flex justify-content-center">
            <?php echo e($books->links()); ?>

        </div>
    </div>

    <!-- Link Bootstrap JS (Opsional untuk interaksi JS) -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
<?php /**PATH C:\laragon\www\book-laravel\resources\views/books/index.blade.php ENDPATH**/ ?>